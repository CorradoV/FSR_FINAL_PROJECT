function [s,s_dot,s_ddot,delta_now] = poly_7_fix(t_iniz,ttot,tf,pi,pf,is_viapoint,delta)
%% SAMPLING TIME
Ts=0.001;

si=0;

sf=norm(pf-pi);
delta_now=delta;
t_start=0;
T_end=ttot-t_iniz;


A = [t_start^7, t_start^6, t_start^5, t_start^4, t_start^3, t_start^2, t_start, 1;
        T_end^7, T_end^6, T_end^5, T_end^4, T_end^3, T_end^2, T_end, 1;
        7*t_start^6, 6*t_start^5, 5*t_start^4, 4*t_start^3, 3*t_start^2, 2*t_start, 1, 0;
        7*T_end^6, 6*T_end^5, 5*T_end^4, 4*T_end^3, 3*T_end^2, 2*T_end, 1, 0;
        42*t_start^5, 30*t_start^4, 20*t_start^3, 12*t_start^2, 6*t_start, 2, 0, 0;
        42*T_end^5, 30*T_end^4, 20*T_end^3, 12*T_end^2, 6*T_end, 2, 0, 0;
        210*t_start^4, 120*t_start^3, 60*t_start^2, 24*t_start, 6, 0, 0, 0;
        210*T_end^4, 120*T_end^3, 60*T_end^2, 24*T_end, 6, 0, 0, 0];


    b = [si sf 0 0 0 0 0 0]';
    a_temp = A\b;
    a7 = a_temp(1);
    a6 = a_temp(2);
    a5 = a_temp(3);
    a4 = a_temp(4);
    a3 = a_temp(5);
    a2 = a_temp(6);
    a1 = a_temp(7);
    a0 = a_temp(8);
 t_temp=linspace(t_start,T_end,round((T_end-t_start)/Ts));
    
    s_temp=a7*t_temp.^7 + a6*t_temp.^6 + a5*t_temp.^5 +a4*t_temp.^4 +a3*t_temp.^3 +a2*t_temp.^2 +a1*t_temp +a0;
    s_dot_temp=7*a7*t_temp.^6 + 6*a6*t_temp.^5 + 5*a5*t_temp.^4 +4*a4*t_temp.^3 +3*a3*t_temp.^2 +2*a2*t_temp +a1;
    s_ddot_temp=42*a7*t_temp.^5 + 30*a6*t_temp.^4 + 5*4*a5*t_temp.^3 +4*3*a4*t_temp.^2 +3*2*a3*t_temp +2*a2;

    

if is_viapoint==0
        if t_iniz==0
        
        
        T_middle=linspace(t_iniz,ttot,round((ttot-t_iniz)/Ts));
        T_end=linspace(ttot,tf,round((tf-ttot)/Ts));
        
        
        % s(1:length(T_iniz)-1)=si;
        % s_dot(1:length(T_iniz)-1)=0;
        % s_ddot(1:length(T_iniz)-1)=0;
        
        t_middle=T_middle(1:end-1);
        
        s(1:length(T_middle))=s_temp;
        s_dot(1:length(T_middle))=s_dot_temp;
        s_ddot(1:length(T_middle))=s_ddot_temp;
        
        s(length(T_middle):length(T_middle)+length(T_end))=sf;
        s_dot(length(T_middle):length(T_middle)+length(T_end))=0;
        s_ddot(length(T_middle):length(T_middle)+length(T_end))=0;
        else
        
        T_iniz=linspace(0,t_iniz,round((t_iniz-0)/Ts));
        T_middle=linspace(t_iniz,ttot,round((ttot-t_iniz)/Ts));
        T_end=linspace(ttot,tf,round((tf-ttot)/Ts));
        
        t_middle=T_middle(1:end);
        
        s(1:length(T_iniz))=si;
        s_dot(1:length(T_iniz))=0;
        s_ddot(1:length(T_iniz))=0;
        
        s(length(T_iniz):length(T_iniz)+length(T_middle)-1)=s_temp;
        s_dot(length(T_iniz):length(T_iniz)+length(T_middle)-1)=s_dot_temp;
        s_ddot(length(T_iniz):length(T_iniz)+length(T_middle)-1)=s_ddot_temp;

        s(length(T_iniz)+length(T_middle):length(T_iniz)+length(T_middle)+length(T_end))=sf;
        s_dot(length(T_iniz)+length(T_middle):length(T_iniz)+length(T_middle)+length(T_end))=0;
        s_ddot(length(T_iniz)+length(T_middle):length(T_iniz)+length(T_middle)+length(T_end))=0;
        end
else
T_iniz=linspace(0,t_iniz,round((t_iniz-0)/Ts));
T_middle=linspace(t_iniz,ttot,round((ttot-t_iniz)/Ts));
T_end=linspace(ttot,tf,round((tf-ttot)/Ts));
        
t_middle=T_middle(1:end);
        
 s(1:length(T_iniz)-1000*delta)=si;
 s_dot(1:length(T_iniz)-1000*delta)=0;
 s_ddot(1:length(T_iniz)-1000*delta)=0;
        
 s(length(T_iniz)-1000*delta+1:length(T_iniz)+length(T_middle)-1000*delta)=s_temp;
 s_dot(length(T_iniz)-1000*delta+1:length(T_iniz)+length(T_middle)-1000*delta)=s_dot_temp;
 s_ddot(length(T_iniz)-1000*delta+1:length(T_iniz)+length(T_middle)-1000*delta)=s_ddot_temp;
        
 s(length(T_iniz)+length(T_middle)-1000*delta+1:length(T_iniz)+length(T_middle)+length(T_end))=sf;
 s_dot(length(T_iniz)+length(T_middle)-1000*delta+1:length(T_iniz)+length(T_middle)+length(T_end))=0;
 s_ddot(length(T_iniz)+length(T_middle)-1000*delta+1:length(T_iniz)+length(T_middle)+length(T_end))=0;       

end

end