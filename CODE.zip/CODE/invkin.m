function q = invkin(p,a1,a2)
c2=(p(1)^2+p(2)^2-a1^2-a2^2)/(2*a1*a2);
s2=-sqrt(1-c2^2);

s1=((a1+a2*c2)*p(2)-a2*s2*p(1))/(p(1)^2+p(2)^2);
c1=((a1+a2*c2)*p(1)+a2*s2*p(2))/(p(1)^2+p(2)^2);

q(1)=atan2(s1,c1);
q(2)=atan2(s2,c2);

end