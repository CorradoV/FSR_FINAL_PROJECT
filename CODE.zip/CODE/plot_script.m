%% plotting path
P(3,:)=P(3,:)*-1;
temp=P(1,:);

P(1,:)=P(2,:);
P(2,:)=temp;

Track_path(:,3)=Track_path(:,3)*-1;
temp=Track_path(:,1);

Track_path(:,1)=Track_path(:,2);
Track_path(:,2)=temp;
figure
plot3(P(1,:),P(2,:),P(3,:),'LineWidth',1.5)
 hold on
 plot3(Track_path(:,1),Track_path(:,2),Track_path(:,3),'o','MarkerFaceColor','r','LineWidth',0.1)
 grid on

%% hierarchical

% tracking path
out.pos.signals.values(:,3)=out.pos.signals.values(:,3)*-1;
temp=out.pos.signals.values(:,1);

out.pos.signals.values(:,1)=out.pos.signals.values(:,2);
out.pos.signals.values(:,2)=temp;
figure
show3D(scena_sim_good)

 xlabel('x')
 ylabel('y')
 zlabel('z')
 grid on
 hold on
 plot3(out.pos.signals.values(:,1),out.pos.signals.values(:,2),out.pos.signals.values(:,3),'LineWidth',1,'Color','b')
 hold on 
 scatter3(out.pos.signals.values(end,1),out.pos.signals.values(end,2),out.pos.signals.values(end,3),'red','filled')

 

% error position
figure()
plot(out.err_p.time,out.err_p.signals.values(:,:),'lineWidth',1.5)
xlabel('time[sec]','Interpreter','latex')
ylabel('$e_p$ ','Interpreter','latex')
grid("on");
xlim([0 360])
hold on
legend('$e_{p_x}$','$e_{p_y}$','$e_{p_z}$','Interpreter', 'latex')
set(gca,'Fontsize',14)

% error linear velocity
figure()
plot(out.dot_err_p.time,out.dot_err_p.signals.values(:,:)  ,'lineWidth',1.5)
xlabel('time[sec]','Interpreter','latex')
ylabel('$\dot{e_p}$ ','Interpreter','latex')
hold on
legend('$\dot{e_{p_x}}$','$\dot{e_{p_y}}$','$\dot{e_{p_z}}$','Interpreter', 'latex')
grid("on");
xlim([0 360])
set(gca,'Fontsize',14)

% error in dot_err_eta
figure()
plot(out.dott_err_eta.time,out.dott_err_eta.signals.values(:,:),'lineWidth',1.5)
xlabel('time[sec]','Interpreter','latex')
ylabel('$e_{\dot{\eta}}$ ','Interpreter','latex')
hold on
legend('${e_{\dot{\phi}}}$','${e_{\dot{\theta}}}$','${e_{\dot{\psi}}}$','Interpreter', 'latex')
grid("on");
xlim([0 360])
set(gca,'Fontsize',14)

% error in err_eta
figure()
plot(out.err_eta.time,out.err_eta.signals.values(:,:),'lineWidth',1.5)
xlabel('time[sec]','Interpreter','latex')
ylabel('$e_{\eta}$ ','Interpreter','latex')
hold on
legend('$e_{\phi}$','$e_{\theta}$','$e_{\psi}$','Interpreter', 'latex')
grid("on");
xlim([0 360])
set(gca,'Fontsize',14)


% u_T
figure()
plot(out.uT.time,out.uT.signals.values(:,:),'lineWidth',1)
xlabel('time[sec]','Interpreter','latex')
ylabel('$u_T$ ','Interpreter','latex')
grid("on");
xlim([0 360])
set(gca,'Fontsize',14)

% tau_B
figure()
plot(out.tau_b.time,out.tau_b.signals.values(:,:),'lineWidth',1)
xlabel('time[sec]','Interpreter','latex')
ylabel('$\tau_b$ ','Interpreter','latex')
hold on
legend('$\tau_x$','$\tau_y$','$\tau_z$','Interpreter', 'latex')
grid("on");
xlim([0 360])
set(gca,'Fontsize',14)


% % RPY_deg
% yaw=zeros(length(out.u_t.time),1);
% for i=1:length(out.u_t.time)
% yaw(i)= atan(out.Rb(2,1,i)/out.Rb(1,1,i));
% end
% figure()
% plot(out.u_t.time,yaw,'lineWidth',1)
% hold on
% plot(out.psi_des, 'lineWidth',1)
% xlabel('time[sec]','Interpreter','latex')
% ylabel('$yaw [rad]$ ','Interpreter','latex')
% grid("on");
% hold on
% legend('$\psi$','$\psi_d$','Interpreter', 'latex')
% set(gca,'Fontsize',14)
%% geometrical

% tracking path
out.pos.signals.values(:,3)=out.pos.signals.values(:,3)*-1;
temp=out.pos.signals.values(:,1);

out.pos.signals.values(:,1)=out.pos.signals.values(:,2);
out.pos.signals.values(:,2)=temp;
figure
show3D(scena_sim_good)

 xlabel('x')
 ylabel('y')
 zlabel('z')
 grid on
 hold on
 plot3(out.pos.signals.values(:,1),out.pos.signals.values(:,2),out.pos.signals.values(:,3),'LineWidth',1,'Color','b')
 hold on 
 scatter3(out.pos.signals.values(end,1),out.pos.signals.values(end,2),out.pos.signals.values(end,3),'red','filled')

 

% error position
figure()
plot(out.err_p.time,out.err_p.signals.values(:,:),'lineWidth',1.5)
xlabel('time[sec]','Interpreter','latex')
ylabel('$e_p$ ','Interpreter','latex')
grid("on");
xlim([0 360])
hold on
legend('$e_{p_x}$','$e_{p_y}$','$e_{p_z}$','Interpreter', 'latex')
set(gca,'Fontsize',14)

% error linear velocity
figure()
plot(out.dot_err_p.time,out.dot_err_p.signals.values(:,:)  ,'lineWidth',1.5)
xlabel('time[sec]','Interpreter','latex')
ylabel('$\dot{e_p}$ ','Interpreter','latex')
hold on
legend('$\dot{e_{p_x}}$','$\dot{e_{p_y}}$','$\dot{e_{p_z}}$','Interpreter', 'latex')
grid("on");
xlim([0 360])
set(gca,'Fontsize',14)

% error in R
figure()
plot(out.err_R1.time,out.err_R1.signals.values(:,:),'lineWidth',1)
xlabel('time[sec]','Interpreter','latex')
ylabel('$e_{R}$ ','Interpreter','latex')
hold on
legend('$e_{R_x}$','$e_{R_y}$','$e_{R_z}$','Interpreter', 'latex')
grid("on");
xlim([0 360])
set(gca,'Fontsize',14)

%error in w 
figure()
plot(out.err_W1.time,out.err_W1.signals.values(:,:),'lineWidth',1)
xlabel('time[sec]','Interpreter','latex')
ylabel('$e_{\omega}$ ','Interpreter','latex')
hold on
legend('$e_{\omega_{x}}$','$e_{\omega_{y}}$','$e_{\omega_{z}}$','Interpreter', 'latex')
grid("on");
xlim([0 360])
set(gca,'Fontsize',14)


% u_T
figure()
plot(out.uT.time,out.uT.signals.values(:,:),'lineWidth',1)
xlabel('time[sec]','Interpreter','latex')
ylabel('$u_T$ ','Interpreter','latex')
grid("on");
xlim([0 360])
set(gca,'Fontsize',14)

% tau_B
figure()
plot(out.tau_b.time,out.tau_b.signals.values(:,:),'lineWidth',1)
xlabel('time[sec]','Interpreter','latex')
ylabel('$\tau_b$ ','Interpreter','latex')
hold on
legend('$\tau_x$','$\tau_y$','$\tau_z$','Interpreter', 'latex')
grid("on");
xlim([0 360])
set(gca,'Fontsize',14)

%% estimator plot

figure()
plot(out.est_fe.time,out.est_fe.signals.values(:,:),'lineWidth',1.5)
xlabel('time[sec]','Interpreter','latex')
ylabel('$\hat{f_e}$ ','Interpreter','latex')
hold on
plot(out.est_fe.time,0.2*mass*9.81.*ones(length(out.est_fe.time),1),'lineWidth',1,'LineStyle','--')
hold on
legend('$\hat{f_{e,x}}$','$\hat{f_{e,y}}$','$\hat{f_{e,z}}$','$f_{e,z}$','Interpreter', 'latex')
grid("on");
xlim([0 360])
set(gca,'Fontsize',14)
%% manip plot
figure()
plot(out.est_fe.time,out.est_fe.signals.values(:,:),'lineWidth',1.5)
xlabel('time[sec]','Interpreter','latex')
ylabel('$\hat{f_e}$ ','Interpreter','latex')
hold on
legend('$\hat{f_{e,x}}$','$\hat{f_{e,y}}$','$\hat{f_{e,z}}$','Interpreter', 'latex')
grid("on");
xlim([0 360])
set(gca,'Fontsize',14)

figure()
plot(out.est_taue.time,out.est_taue.signals.values(:,:),'lineWidth',1.5)
xlabel('time[sec]','Interpreter','latex')
ylabel('$\hat{\tau_e}$ ','Interpreter','latex')
hold on
legend('$\hat{\tau_{e,x}}$','$\hat{\tau_{e,y}}$','$\hat{\tau_{e,z}}$','Interpreter', 'latex')
grid("on");
xlim([0 360])
set(gca,'Fontsize',14)

% figure()
% plot(out.xeinvdin.time,out.xeinvdin.signals.values(:,:),'lineWidth',1.5)
% xlabel('time[sec]','Interpreter','latex')
% ylabel('$p_m$ ','Interpreter','latex')
% hold on
% legend('$x_m$','$y_m$','Interpreter', 'latex')
% grid("on");
% xlim([0 360])
% set(gca,'Fontsize',14)