clear all
close all
clc
%% trajectory
a1=0.15;
a2=0.05;
p0=[0.05 0.1]';
   p1=[0.15 0.12]';

q0=invkin(p0,a1,a2);


Tman_i=300;% duration time of each segment
Tman_f=310;
[s, s_dot ,s_dot_dot]=poly_7_fix(Tman_i,Tman_f,360,p0,p1,0,0);
s=s(Tman_i*1000:end);
s_dot=s_dot(Tman_i*1000:end);
s_dot_dot=s_dot_dot(Tman_i*1000:end);
P= p0+ s.*(p1-p0)/norm(p1-p0);
P=[p0.*ones(2,Tman_i*1000) P(:,1:end-1)];

P_dot= s_dot.*(p1-p0)/norm(p1-p0);

P_dot=[zeros(2,Tman_i*1000) P_dot(:,1:end-1)];

P_ddot= s_dot_dot.*(p1-p0)/norm(p1-p0);

P_ddot=[zeros(2,Tman_i*1000) P_ddot(:,1:end-1)];

t=linspace(0,360,1000*360);

 figure 
 plot(t,P);
 grid on

 figure
 plot(t,P_dot);
 grid on

 figure
 plot(t,P_ddot);
 grid on

 
 Xd = timeseries(P,t);
 Xd_dot = timeseries(P_dot,t);
 Xd_ddot = timeseries(P_ddot,t);