clc
clear all
close all

load("GOOD_PATH.mat")
load("scene_sim_good.mat")

% Transform ref in NED fram

Track_path(:,3)=Track_path(:,3)*-1;
temp=Track_path(:,1);

Track_path(:,1)=Track_path(:,2);
Track_path(:,2)=temp;

%tk=[0 10 20 30 50 80 120];
tk=[0 40 80 120 200 280 360];
tF=360;
t_dead=130;

Ts=0.001;
psi=[0 -pi/6 -pi/2 0 pi/6 pi/2 pi];
% psi=[0 -pi/2 pi];

[s1, s_dot1 ,s_dot_dot1,delta1]=poly_7_fix(tk(1),tk(2),tF,Track_path(1,:),Track_path(2,:),0,0);
[s2, s_dot2 ,s_dot_dot2,delta2]=poly_7_fix(tk(2),tk(3),tF,Track_path(2,:),Track_path(3,:),0,0);
[s3, s_dot3 ,s_dot_dot3,delta3]=poly_7_fix(tk(3),tk(4),tF,Track_path(3,:),Track_path(4,:),1,delta2+20);
[s4, s_dot4 ,s_dot_dot4,delta4]=poly_7_fix(tk(4),tk(5),tF,Track_path(4,:),Track_path(5,:),1,delta3+20);
[s5, s_dot5 ,s_dot_dot5,delta5]=poly_7_fix(tk(5),tk(6),tF,Track_path(5,:),Track_path(6,:),1,delta4+20);
[s6, s_dot6 ,s_dot_dot6,delta6]=poly_7_fix(tk(6),tk(7),tF,Track_path(6,:),Track_path(7,:),1,delta5+20);


P1= Track_path(1,:)'+ s1.*(Track_path(2,:)'-Track_path(1,:)')/norm(Track_path(2,:)'-Track_path(1,:)');
P2=(s2.*(Track_path(3,:)'-Track_path(2,:)'))/norm(Track_path(3,:)'-Track_path(2,:)');
P3=(s3.*(Track_path(4,:)'-Track_path(3,:)'))/norm(Track_path(4,:)'-Track_path(3,:)');
P4=(s4.*(Track_path(5,:)'-Track_path(4,:)'))/norm(Track_path(5,:)'-Track_path(4,:)');
P5=(s5.*(Track_path(6,:)'-Track_path(5,:)'))/norm(Track_path(6,:)'-Track_path(5,:)');
P6=(s6.*(Track_path(7,:)'-Track_path(6,:)'))/norm(Track_path(7,:)'-Track_path(6,:)');



P=P1+P2+P3+P4+P5+P6;
t=linspace(0,tF,round((tF-0)/Ts));

figure 
plot(t,P)


figure
plot3(P(1,:),P(2,:),P(3,:))
 hold on
 plot3(Track_path(:,1),Track_path(:,2),Track_path(:,3),'o','MarkerFaceColor','r')
 grid on

 %% Vel
 P1dot=(s_dot1.*(Track_path(2,:)'-Track_path(1,:)'))/norm(Track_path(2,:)'-Track_path(1,:)');
 P2dot=(s_dot2.*(Track_path(3,:)'-Track_path(2,:)'))/norm(Track_path(3,:)'-Track_path(2,:)');
 P3dot=(s_dot3.*(Track_path(4,:)'-Track_path(3,:)'))/norm(Track_path(4,:)'-Track_path(3,:)');
 P4dot=(s_dot4.*(Track_path(5,:)'-Track_path(4,:)'))/norm(Track_path(5,:)'-Track_path(4,:)');
 P5dot=(s_dot5.*(Track_path(6,:)'-Track_path(5,:)'))/norm(Track_path(6,:)'-Track_path(5,:)');
 P6dot=(s_dot6.*(Track_path(end,:)'-Track_path(6,:)'))/norm(Track_path(end,:)'-Track_path(6,:)');


 Pdot=P1dot+P2dot+P3dot+P4dot+P5dot+P6dot;
figure()
 plot(t,Pdot);
 %% accelerazioni
  P1dotdot=(s_dot_dot1.*(Track_path(2,:)'-Track_path(1,:)'))/norm(Track_path(2,:)'-Track_path(1,:)');
 P2dotdot=(s_dot_dot2.*(Track_path(3,:)'-Track_path(2,:)'))/norm(Track_path(3,:)'-Track_path(2,:)');
 P3dotdot=(s_dot_dot3.*(Track_path(4,:)'-Track_path(3,:)'))/norm(Track_path(4,:)'-Track_path(3,:)');
 P4dotdot=(s_dot_dot4.*(Track_path(5,:)'-Track_path(4,:)'))/norm(Track_path(5,:)'-Track_path(4,:)');
 P5dotdot=(s_dot_dot5.*(Track_path(6,:)'-Track_path(5,:)'))/norm(Track_path(6,:)'-Track_path(5,:)');
 P6dotdot=(s_dot_dot6.*(Track_path(end,:)'-Track_path(6,:)'))/norm(Track_path(end,:)'-Track_path(6,:)');


 Pdotdot=P1dotdot+P2dotdot+P3dotdot+P4dotdot+P5dotdot+P6dotdot;
 figure()
 plot(t,Pdotdot);
%% ORIENTAMENTO

 [ps1 ,ps1dot, ps1dotdot,delta1psi]=poly_7_fix(tk(1),tk(2),tF,psi(1),psi(2),0,0);
[ps2 ,ps2dot, ps2dotdot,delta2psi]=poly_7_fix(tk(2),tk(3),tF,psi(2),psi(3),0,delta1psi+5);
[ps3 ,ps3dot, ps3dotdot,delta3psi]=poly_7_fix(tk(3),tk(4),tF,psi(3),psi(4),0,delta2psi+5);
[ps4 ,ps4dot, ps4dotdot,delta4psi]=poly_7_fix(tk(4),tk(5),tF,psi(4),psi(5),0,delta3psi+5);
[ps5 ,ps5dot, ps5dotdot,delta5psi]=poly_7_fix(tk(5),tk(6),tF,psi(5),psi(6),0,delta4psi+5);
[ps6 ,ps6dot, ps6dotdot,delta6psi]=poly_7_fix(tk(6),tk(7),tF,psi(6),psi(7),0,delta5psi+5);

psi_des=psi(1)+ps1.*(psi(2)-psi(1))/norm(psi(2)-psi(1))+ps2.*(psi(3)-psi(2))/norm(psi(3)-psi(2))+ps3.*(psi(4)-psi(3))/norm(psi(4)-psi(3))+ps4.*(psi(5)-psi(4))/norm(psi(5)-psi(4))+ps5.*(psi(6)-psi(5))/norm(psi(6)-psi(5))+ps6.*(psi(7)-psi(6))/norm(psi(7)-psi(6));
dot_psi_des=ps1dot.*(psi(2)-psi(1))/norm(psi(2)-psi(1))+ps2dot.*(psi(3)-psi(2))/norm(psi(3)-psi(2))+ps3dot.*(psi(4)-psi(3))/norm(psi(4)-psi(3))+ps4dot.*(psi(5)-psi(4))/norm(psi(5)-psi(4))+ps5dot.*(psi(6)-psi(5))/norm(psi(6)-psi(5))+ps6dot.*(psi(7)-psi(6))/norm(psi(7)-psi(6));
ddot_psi_des=ps1dotdot.*(psi(2)-psi(1))/norm(psi(2)-psi(1))+ps2dotdot.*(psi(3)-psi(2))/norm(psi(3)-psi(2))+ps3dotdot.*(psi(4)-psi(3))/norm(psi(4)-psi(3))+ps4dotdot.*(psi(5)-psi(4))/norm(psi(5)-psi(4))+ps5dotdot.*(psi(6)-psi(5))/norm(psi(6)-psi(5))+ps6dotdot.*(psi(7)-psi(6))/norm(psi(7)-psi(6));

figure
plot(t,psi_des);

grid on

%% passing references
position_d=timeseries(P,t);
linear_vel_d=timeseries(Pdot,t);
acc_d=timeseries(Pdotdot,t);

psi_ref=timeseries(psi_des,t);
dot_psi_ref=timeseries(dot_psi_des,t);
ddot_psi_ref=timeseries(ddot_psi_des,t);

